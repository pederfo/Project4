This folder contains a number of .dat files.
This file shows the paramteres used for producing each of those files

analytical.dat
 n_spins = 2; mcs = 1000000;  initial_temp = 1; final_temp = 1; temp_step =0.05; method = 0,ordered=true;
acceptedmoves.dat
 n_spins = 20; mcs = 1000000;  initial_temp = 1; final_temp = 3; temp_step =0.05; method = 1,ordered=true;
expecttemp.dat
 n_spins = 20; mcs = 1000000;  initial_temp = 2.0; final_temp = 2.7; temp_step =0.025; method = 2,ordered=true;
expectmc.dat
 n_spins = 20; mcs = 1000000;  initial_temp = 2.0; final_temp = 2.0; temp_step =0.05; method = 3,ordered=true;
energies.dat
 n_spins = 20; mcs = 1000000;  initial_temp = 2.0; final_temp = 2.0; temp_step =0.05; method = 4,ordered=true;
L20.dat
 n_spins = 20; mcs = 1000000;  initial_temp = 2.0; final_temp = 2.7; temp_step =0.01; method = 2,ordered=true;
L40.dat
 n_spins = 40; mcs = 1000000;  initial_temp = 2.0; final_temp = 2.7; temp_step =0.01; method = 2,ordered=true;
L60.dat
 n_spins = 60; mcs = 1000000;  initial_temp = 2.0; final_temp = 2.7; temp_step =0.01; method = 2,ordered=true;
L80.dat
 n_spins = 80; mcs = 1000000;  initial_temp = 2.0; final_temp = 2.7; temp_step =0.01; method = 2,ordered=true;

